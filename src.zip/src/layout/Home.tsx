/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState, useRef } from "react";
import { useNavigate, Outlet } from "react-router-dom";
import { CgProfile } from "react-icons/cg";
import { FaChevronDown } from "react-icons/fa";
import { getDiligenceFabricSDK } from "../services/DFService";
import { DefaultIcon } from "../assets/icons";
import config from "../config/default.json";
import logo from "../assets/DF-Logo.svg";

// ---- Types ----
export interface MenuItem {
  AppMenuID: number;
  AppMenuLabel: string;
  AppMenuURL?: string;
  ParenAppMenuID?: number;
  children?: MenuItem[];
  childMenus?: MenuItem[];
  child_Menus?: MenuItem[];
  link?: string;
}

// ---- Helpers ----
const routeForLabel = (label: string): string => {
  switch (label) {
    case "Submit Expense Form":
      return "/submit-expense";
    case "Expense History":
      return "/expense-history";
    case "Manager Approvals":
      return "/manager-approvals";
    case "Reports and Export":
      return "/reports-export";
    default:
      return "/home";
  }
};

const organizeMenuHierarchy = (items: MenuItem[]): MenuItem[] => {
  const map: Record<number, MenuItem & { children: MenuItem[] }> = {};
  const roots: (MenuItem & { children: MenuItem[] })[] = [];

  items.forEach((item) => {
    map[item.AppMenuID] = { ...item, children: [] };
  });

  items.forEach((item) => {
    const parentId = item.ParenAppMenuID ?? 0;
    if (parentId === 0) {
      roots.push(map[item.AppMenuID]);
    } else if (map[parentId]) {
      map[parentId].children.push(map[item.AppMenuID]);
    }
  });

  return roots;
};

// ---- Child Components ----

const DropdownMenu: React.FC<{ items: MenuItem; onNavigate: (to: string) => void }> = ({
  items,
  onNavigate
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const kids: MenuItem[] =
    items.children || items.childMenus || items.child_Menus || [];

  return (
    <div
      className="relative group"
      onMouseEnter={() => setIsMenuOpen(true)}
      onMouseLeave={() => setIsMenuOpen(false)}
    >
      <button className="py-2 px-4 hover:bg-primary-50 text-black">
        {items.AppMenuLabel}
      </button>

      {kids.length > 0 && (
        <div
          className={`absolute left-1 mt-2 bg-white border rounded shadow-lg ${
            isMenuOpen ? "block" : "hidden"
          }`}
        >
          <ul className="py-2">
            {kids.map((child: MenuItem) => {
              const grandKids =
                child.children || child.childMenus || child.child_Menus || [];
              const childUrl = child.AppMenuURL ?? child.link ?? routeForLabel(child.AppMenuLabel);

              return (
                <li key={child.AppMenuID} className="relative group whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => onNavigate(childUrl)}
                    className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                  >
                    {child.AppMenuLabel}
                  </button>

                  {grandKids.length > 0 && (
                    <div className="absolute left-full top-0 bg-white border rounded shadow-lg hidden group-hover:block">
                      <DropdownMenu items={child} onNavigate={onNavigate} />
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
};

const TopMenu: React.FC<{ menuItems: MenuItem[]; onNavigate: (to: string) => void }> = ({
  menuItems,
  onNavigate
}) => {
  const [openMenu, setOpenMenu] = useState<number | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  return (
    <div className="relative" ref={menuRef}>
      <ul className="flex items-center space-x-4">
        {menuItems.map((item: MenuItem) => {
          const kids = item.children || item.childMenus || item.child_Menus || [];
          const itemUrl = item.AppMenuURL ?? item.link ?? routeForLabel(item.AppMenuLabel);

          return (
            <li
              key={item.AppMenuID}
              className="relative"
              onMouseEnter={() => setOpenMenu(item.AppMenuID)}
              onMouseLeave={() => setOpenMenu((prev) => (prev === item.AppMenuID ? null : prev))}
            >
              <button
                type="button"
                onClick={() => onNavigate(itemUrl)}
                className="px-3 py-2 hover:text-primary-200"
              >
                {item.AppMenuLabel}
              </button>

              {openMenu === item.AppMenuID && kids.length > 0 && (
                <ul className="absolute left-0 mt-2 bg-white border rounded shadow-lg z-50">
                  {kids.map((child: MenuItem) => {
                    const childUrl =
                      child.AppMenuURL ?? child.link ?? routeForLabel(child.AppMenuLabel);
                    const grandKids =
                      child.children || child.childMenus || child.child_Menus || [];

                    return (
                      <li key={child.AppMenuID} className="relative group whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => onNavigate(childUrl)}
                          className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                        >
                          {child.AppMenuLabel}
                        </button>

                        {grandKids.length > 0 && (
                          <div className="absolute left-full top-0 bg-white border rounded shadow-lg hidden group-hover:block">
                            <DropdownMenu items={child} onNavigate={onNavigate} />
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
};

// ---- Main Layout Component ----
const Main: React.FC = () => {
  const navigate = useNavigate();

  // Menu state
  const [appMenuItems, setAppMenuItems] = useState<MenuItem[]>([]);
  const [nestedMenuItems, setNestedMenuItems] = useState<MenuItem[]>([]);
  const [activeMenu, setActiveMenu] = useState<number | null>(null);

  // Profile dropdown
  const [open, setOpen] = useState(false);

  // Username (read from localStorage userData and now USED in UI)
  const [username, setUsername] = useState("");

  // Track which side-menu IDs are open (accordion)
  const [openMenus, setOpenMenus] = useState<Record<number, boolean>>({});

  const menuLocation = String(config.PUBLIC_MENU_LOCATION ?? "side");

  const toggleDropdown = () => setOpen((v) => !v);

  const handleToggle = (menuId: number) => {
    setOpenMenus((prev) => ({ ...prev, [menuId]: !prev[menuId] }));
  };

  const sideMenuhandleItemClick = (item: MenuItem) => {
    const url = item.AppMenuURL ?? item.link ?? routeForLabel(item.AppMenuLabel);
    navigate(url);
    setActiveMenu(item.AppMenuID);
  };

  const fetchDataMenu = async () => {
    try {
      const client = getDiligenceFabricSDK();
      const data = JSON.parse(localStorage.getItem("userData") || "{}");

      const token: string | undefined = data.Token;
      const name: string = String(data.UserName ?? data.Username ?? "");
      if (name) setUsername(name);

      if (!token) {
        console.error("User token not set. Redirecting to login...");
        navigate("/login");
        return;
      }

      const appMenuListResponse = await client
        .getApplicationRoleService()
        .getAllAccessibleMenus();

      if (!Array.isArray(appMenuListResponse)) {
        console.error("Invalid menu response:", appMenuListResponse);
        setAppMenuItems([]);
        return;
      }

      setAppMenuItems(appMenuListResponse as MenuItem[]);
    } catch (error) {
      console.error("Error fetching data:", error);
      navigate("/login");
    }
  };

  useEffect(() => {
    fetchDataMenu();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (appMenuItems.length > 0) {
      setNestedMenuItems(organizeMenuHierarchy(appMenuItems));
    } else {
      setNestedMenuItems([]);
    }
  }, [appMenuItems]);

  // Recursive side-menu renderer
  const renderSidebarMenuItems = (menuItems: MenuItem[]) =>
    menuItems.map((item) => {
      const isActive = item.AppMenuID === activeMenu;
      const isSubmenuOpen = openMenus[item.AppMenuID] || false;
      const kids = item.children || item.childMenus || item.child_Menus || [];

      return (
        <div key={item.AppMenuID} className="relative flex flex-col space-y-2 bg-white">
          <div
            className={`flex items-center p-2 rounded-lg transition-colors duration-200 ${
              kids.length > 0 ? "cursor-pointer text-black" : "cursor-pointer hover:text-primary-200"
            } ${isActive ? "bg-primary-50 text-white font-bold hover:text-white" : ""}`}
            onClick={() => sideMenuhandleItemClick(item)}
          >
            <DefaultIcon />
            <ul className="list-none">
              <li className="text-base ml-3 inline">{item.AppMenuLabel}</li>
            </ul>

            {kids.length > 0 && (
              <span
                className={`ml-auto transition-transform ${isSubmenuOpen ? "rotate-90" : ""}`}
                onClick={(e) => {
                  e.stopPropagation(); // prevent navigation when toggling
                  handleToggle(item.AppMenuID);
                }}
              >
                <FaChevronDown />
              </span>
            )}
          </div>

          {isSubmenuOpen && kids.length > 0 && (
            <div className="ml-6 pl-4 border-l border-gray-300">
              {renderSidebarMenuItems(kids)}
            </div>
          )}
        </div>
      );
    });

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const renderProfileDropdown = () => (
    <div className="relative">
      <button
        type="button"
        className="cursor-pointer rounded-full"
        onClick={toggleDropdown}
        aria-label="Profile menu"
      >
        <CgProfile size={35} style={{ color: "white" }} />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-md z-50">
          <ul className="py-2">
            <li className="px-4 py-2 text-gray-700">{username ? `Hi, ${username}` : "Profile"}</li>
            <li
              onClick={() => navigate("/change-password")}
              className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
            >
              Change Password
            </li>
            <li
              onClick={handleLogout}
              className="px-4 py-2 text-red-500 hover:bg-gray-100 cursor-pointer"
            >
              Logout
            </li>
          </ul>
        </div>
      )}
    </div>
  );

  // ---- Layout ----
  return (
    <div className="flex flex-col h-screen">
      {menuLocation === "side" ? (
        <div className="flex h-full">
          {/* Sidebar */}
          <aside className="flex flex-col p-5 h-full w-64 bg-white">
            <div className="mb-8 cursor-pointer" onClick={() => navigate("/home")}>
              <img src={logo} className="h-24" alt="Logo" />
            </div>

            <nav>{renderSidebarMenuItems(nestedMenuItems)}</nav>
          </aside>

          {/* Main area */}
          <main className="flex-grow bg-primary-100 p-4 relative">
            <div className="absolute top-4 right-4 flex items-center gap-3 rounded-full mt-2 bg-primary-50 px-3 py-2">
              <span className="text-white text-sm">{username ? `Hi, ${username}` : ""}</span>
              {renderProfileDropdown()}
            </div>

            <div className="p-5">
              <Outlet />
            </div>
          </main>
        </div>
      ) : (
        <>
          {/* Top bar */}
          <header className="flex justify-between text-black items-center p-4 shadow-md border-b border-gray-200 bg-white">
            <div className="flex items-center space-x-4">
              <img
                src={logo}
                className="h-12 cursor-pointer"
                alt="Logo"
                onClick={() => navigate("/home")}
              />
              <nav className="flex space-x-4">
                <TopMenu
                  menuItems={nestedMenuItems}
                  onNavigate={(to) => navigate(to)}
                />
              </nav>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-700">{username ? `Hi, ${username}` : ""}</span>
              <div className="rounded-full">{renderProfileDropdown()}</div>
            </div>
          </header>

          {/* Content */}
          <main className="flex flex-col bg-primary-100 flex-grow">
            <div className="p-5">
              <Outlet />
            </div>
          </main>
        </>
      )}
    </div>
  );
};

export default Main;
