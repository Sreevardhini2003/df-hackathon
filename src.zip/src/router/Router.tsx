import { createBrowserRouter } from "react-router-dom";
import Main from "../layout/Main";
import Login from "../components/Login";
import Home from "../layout/Home";
import SubmitExpense from "../pages/SubmitExpense";
import ManagerApprovals from "../pages/ManagerApprovals";
import ExpenseHistory from "../pages/ExpenseHistory";
import ReportsExport from "../pages/ReportsExport";
import ChangePassword from "../components/Auth/ChangePassword";
import ForgotPassword from "../components/Auth/ForgotPassword";
import Dashboard from "../pages/Dashboard";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Main />,
    children: [
      {
        path: "/",
        element: <Login />,
      },
      {
        path: "/login",
        element: <Login />,
      },
      {
        path: "/home",
        element: <Home />, // Home layout with sidebar
        children: [
          { index: true, element: <Dashboard /> }, 
          { path: "dashboard", element: <Dashboard /> },
          { path: "submit-expense", element: <SubmitExpense /> },
          { path: "expense-history", element: <div>Expense History</div> },
          { path: "reports-export", element: <div>Reports Export</div> },
        ],
      },
      {
        path: "/submit-expense",
        element: <SubmitExpense />
      },
      
      {
        path: "/expense-history",
        element: <ExpenseHistory />
      },
      {
        path: "/manager-approvals",
        element: <ManagerApprovals />
      },
      {
        path: "/reports-export",
        element: <ReportsExport />
      },
      

      {
        path: "/change-password",
        element: <ChangePassword />,
      },
      {
        path: "/forgot-password",
        element: <ForgotPassword />,
      },
    ],
  },
]);

export default router;