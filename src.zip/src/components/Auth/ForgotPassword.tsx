import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { getDiligenceFabricSDK } from "../../services/DFService";
import { showToast } from "../../utils/toastUtils";
import DFLogo from "../../assets/DF-Logo.svg"; // use import so Vite bundles the asset

// A safe shape for SDK responses
interface ApiResponse<T = unknown> {
  StatusCode: number;
  Message?: string;
  Result?: T;
}

const ForgotPassword: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [workEmail, setWorkEmail] = useState("");

  const submitForgotPassword = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);

    try {
      const client = getDiligenceFabricSDK();

      const response = (await client
        .getAuthService()
        .forgotPassword({ email: workEmail })) as ApiResponse;

      if (response.StatusCode === 200) {
        showToast("Email sent", "success");
        navigate("/");
      } else {
        throw new Error(response.Message ?? "Forgot Password failed");
      }
    } catch (error) {
      console.error("Error Forgot Password:", error);
      showToast("Forgot Password request failed", "error");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="relative">
        <h1 className="absolute left-1/2 -translate-x-1/2 mb-14">
          <img src={DFLogo} className="h-24 w-auto max-w-full" alt="Logo" />
        </h1>

        <div className="bg-white rounded-lg shadow-lg p-8 max-w-lg w-full mt-20">
          <h4 className="text-2xl font-heading font-bold text-gray-800 text-left mb-3">
            Forgot Password
          </h4>

          <p className="text-justify mb-4 text-sm text-Text/Secondary">
            Please enter your work email to receive a reset link.
          </p>

          {/* Email Form */}
          <form onSubmit={submitForgotPassword} className="space-y-6 mt-5">
            <div>
              <label
                htmlFor="email"
                className="block text-base font-medium text-gray-700 text-left"
              >
                Work Email
              </label>
              <input
                type="email"
                id="email"
                className="mt-1 block w-full px-4 py-2 border border-gray-600 rounded-md shadow-sm placeholder-gray-400 focus:ring-primary-50 sm:text-sm"
                placeholder="name@email.com"
                onChange={(e) => setWorkEmail(e.target.value)}
                value={workEmail}
                required
              />
            </div>

            <button
              type="submit"
              className="flex w-full justify-center rounded-md bg-primary-50 px-3 py-1.5 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              disabled={isLoading}
            >
              {isLoading ? (
                <div
                  className="w-5 h-5 mt-1 text-center mr-2 rounded-full animate-spin
                  border-4 border-solid border-white border-t-transparent"
                />
              ) : null}
              {isLoading ? "Sending Email" : "Continue with Email"}
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => navigate("/login")}
                className="inline-flex text-primary-50 underline"
              >
                Cancel Reset Password
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;