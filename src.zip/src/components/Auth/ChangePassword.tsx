import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getDiligenceFabricSDK } from "../../services/DFService";
import { showToast } from "../../utils/toastUtils";
import DFLogo from "../../assets/DF-Logo.svg"; // use an import for assets so Vite bundles it

// ----- Types -----
type ChangePwdForm = {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
};

type FormErrors = Partial<Record<keyof ChangePwdForm, string>>;

interface ApiResponse<T = any> {
  StatusCode: number;
  Message?: string;
  Result?: T;
}

const ChangePassword: React.FC = () => {
  const navigate = useNavigate();

  // UI states
  const [error, setError] = useState<string>("");
  const [formError, setFormError] = useState<string>(""); // general form-level error
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSubmit, setIsSubmit] = useState<boolean>(false);

  // Form states
  const [formValues, setFormValues] = useState<ChangePwdForm>({
    oldPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  const [formErrors, setFormErrors] = useState<FormErrors>({});

  // ----- Handlers -----
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const key = name as keyof ChangePwdForm;

    setFormValues(prev => ({ ...prev, [key]: value }));

    // Clear field-specific error when user starts fixing it
    if (formErrors[key] && value) {
      setFormErrors(prev => ({ ...prev, [key]: undefined }));
    }
    // Clear generic form error while editing
    if (formError) setFormError("");
  };

  const validate = (values: ChangePwdForm): FormErrors => {
    const errors: FormErrors = {};

    if (!values.oldPassword) {
      errors.oldPassword = "Old password is required";
    }
    if (!values.newPassword) {
      errors.newPassword = "New password is required";
    }
    if (!values.confirmPassword) {
      errors.confirmPassword = "Confirm password is required";
    } else if (values.newPassword !== values.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
    }

    return errors;
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errors = validate(formValues);
    setFormErrors(errors);
    setIsSubmit(true);

    if (Object.keys(errors).length > 0) {
      setFormError("Please fix the errors above.");
    } else {
      setFormError("");
    }
  };

  useEffect(() => {
    // When validation passes, kick off password change
    if (isSubmit && Object.keys(formErrors).length === 0) {
      changeUserPassword(formValues).catch(() => {
        /* errors handled inside the function */
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formErrors, isSubmit]);

  // ----- API Call -----
  const changeUserPassword = async (passwordData: ChangePwdForm) => {
    setIsLoading(true);
    setError("");

    try {
      const client = getDiligenceFabricSDK();

      const response = (await client
        .getAuthService()
        .changePassword({
          oldPassword: passwordData.oldPassword,
          isResetPassword: 1,
          dfUPassword: passwordData.newPassword
        })) as ApiResponse;

      if (response.Result) {
        localStorage.setItem("userData", JSON.stringify(response.Result));
        showToast("Password changed successfully!", "success");
        navigate(-1);
      } else {
        throw new Error(response.Message ?? "Change Password failed");
      }
    } catch (err) {
      console.error("Error Change Password:", err);
      setError("Change Password Failed");
      showToast("Password Change Failed", "error");
    } finally {
      setIsLoading(false);
    }
  };

  // ----- UI -----
  return (
    <div className="min-h-screen flex items-center justify-center mt-5 px-4">
      <div className="relative w-full max-w-lg">
        {/* Logo Positioned Outside the Box */}
        <div className="absolute -top-16 left-1/2 -translate-x-1/2">
          <img src={DFLogo} className="h-36 w-auto max-w-full" alt="Logo" />
        </div>

        <div className="pt-10">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h4 className="text-2xl font-bold text-gray-800 text-left mb-6">
              Reset Password
            </h4>

            {error && <div className="text-center text-red-500">{error}</div>}

            {/* Password Reset Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Old Password */}
              <div>
                <label
                  htmlFor="oldPassword"
                  className="block text-lg font-medium text-gray-700"
                >
                  Old Password
                </label>
                <input
                  type="password"
                  id="oldPassword"            // ✅ fixed id
                  name="oldPassword"
                  className="mt-2 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:ring-primary-50 focus:border-primary-50 text-base"
                  placeholder="Old Password"
                  value={formValues.oldPassword}
                  onChange={handleChange}
                />
                {formErrors.oldPassword && (
                  <p className="text-red-600">{formErrors.oldPassword}</p>
                )}
              </div>

              {/* New Password */}
              <div>
                <label
                  htmlFor="newPassword"
                  className="block text-lg font-medium text-gray-700"
                >
                  New Password
                </label>
                <input
                  type="password"
                  id="newPassword"
                  name="newPassword"
                  className="mt-2 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:ring-primary-50 focus:border-primary-50 text-base"
                  placeholder="New Password"
                  value={formValues.newPassword}
                  onChange={handleChange}
                />
                {formErrors.newPassword && (
                  <p className="text-red-600">{formErrors.newPassword}</p>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <label
                  htmlFor="confirmPassword"
                  className="block text-lg font-medium text-gray-700"
                >
                  Confirm Password
                </label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  className="mt-2 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:ring-primary-50 focus:border-primary-50 text-base"
                  placeholder="Confirm Password"
                  value={formValues.confirmPassword}
                  onChange={handleChange}
                />
                {formErrors.confirmPassword && (
                  <p className="text-red-600">{formErrors.confirmPassword}</p>
                )}
              </div>

              {/* Form-level error */}
              {formError && (
                <p className="text-sm text-red-500 font-medium mt-2">{formError}</p>
              )}

              {/* Submit */}
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-primary-600 px-3 py-1.5 text-sm font-semibold text-white shadow-sm hover:bg-primary-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="w-5 h-5 mt-1 text-center mr-2 rounded-full animate-spin border-4 border-solid border-white border-t-transparent" />
                ) : null}
                {isLoading ? "Changing Password" : "Change Password"}
              </button>

              {/* Cancel */}
              <div className="text-center mt-4">
                <button
                  type="button"
                  onClick={() => navigate(-1)}
                  className="inline-flex text-gray-600 underline"
                >
                  Cancel Reset Password
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChangePassword;