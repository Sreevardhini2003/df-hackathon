import * as React from 'react';
import {
  Stack,
  TextField,
  Dropdown,
  IDropdownOption,
  DatePicker,
  PrimaryButton,
  Text
} from '@fluentui/react';

const categoryOptions: IDropdownOption[] = [
  { key: 'Travel', text: 'Travel' },
  { key: 'Food', text: 'Food' },
  { key: 'Office Supplies', text: 'Office Supplies' },
  { key: 'Other', text: 'Other' }
];

const SubmitExpense: React.FC = () => {
  const [employees, setEmployees] = React.useState<IDropdownOption[]>([]);
  const [selectedEmployee, setSelectedEmployee] = React.useState<string>('');
  const [amount, setAmount] = React.useState('');
  const [category, setCategory] = React.useState('');
  const [date, setDate] = React.useState<Date | null>(null);
  const [description, setDescription] = React.useState('');
  const [receipt, setReceipt] = React.useState<File | null>(null);
  const [message, setMessage] = React.useState('');

  // ✅ Fetch employees for dropdown
  React.useEffect(() => {
    fetch('http://127.0.0.1:8000/employees')
      .then(res => res.json())
      .then(data => {
        const options = data.map((emp: any) => ({
          key: emp.id.toString(),
          text: emp.name
        }));
        setEmployees(options);
      })
      .catch(() => setMessage('Error loading employees'));
  }, []);

  const handleSubmit = () => {
    if (!selectedEmployee || !amount || !category || !date || !description) {
      setMessage('Please fill all fields.');
      return;
    }

    const formData = new FormData();
    formData.append('employee_id', selectedEmployee);
    formData.append('amount', amount);
    formData.append('category', category);
    formData.append('expense_date', date.toISOString().split('T')[0]);
    formData.append('description', description);
    if (receipt) formData.append('receipt', receipt);

    fetch('http://127.0.0.1:8000/submit-expense', {
      method: 'POST',
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        setMessage(data.message);
        // Reset form
        setSelectedEmployee('');
        setAmount('');
        setCategory('');
        setDate(null);
        setDescription('');
        setReceipt(null);
      })
      .catch(() => setMessage('Error submitting expense'));
  };

  return (
    <Stack tokens={{ childrenGap: 16 }} styles={{ root: { padding: 20, maxWidth: 400 } }}>
      <Text variant="xLarge">Submit Expense</Text>
      {message && <Text styles={{ root: { color: 'green' } }}>{message}</Text>}

      {/* Employee Dropdown */}
      <Dropdown
        label="Employee"
        options={employees}
        selectedKey={selectedEmployee}
        onChange={(_, option) => setSelectedEmployee(option?.key as string)}
        placeholder="Select Employee"
      />

      {/* Amount */}
      <TextField
        label="Amount"
        type="number"
        value={amount}
        onChange={(_, val) => setAmount(val || '')}
      />

      {/* Category */}
      <Dropdown
        label="Category"
        options={categoryOptions}
        selectedKey={category}
        onChange={(_, option) => setCategory(option?.key as string)}
      />

      {/* Date */}
      <DatePicker
        label="Date"
        value={date || undefined}
        onSelectDate={(selectedDate) => setDate(selectedDate || null)}
      />

      {/* Description */}
      <TextField
        label="Description"
        multiline
        rows={3}
        value={description}
        onChange={(_, val) => setDescription(val || '')}
      />

      {/* Receipt Upload */}
      <input
        type="file"
        onChange={(e) => setReceipt(e.target.files ? e.target.files[0] : null)}
      />

      <PrimaryButton text="Submit Expense" onClick={handleSubmit} />
    </Stack>
  );
};

export default SubmitExpense;