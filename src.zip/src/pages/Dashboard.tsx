import * as React from 'react';
import {
  Stack,
  Text,
  Dropdown,
  IDropdownOption,
  IStackStyles,
  IStackTokens
} from '@fluentui/react';
import { Line, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, ArcElement, Title, Tooltip, Legend);

const Dashboard: React.FC = () => {
  const [summary, setSummary] = React.useState<any>(null);
  const [trend, setTrend] = React.useState<any[]>([]);
  const [filterType, setFilterType] = React.useState<string>('all');
  const [selectedId, setSelectedId] = React.useState<string>('');
  const [employees, setEmployees] = React.useState<IDropdownOption[]>([]);
  const [managers, setManagers] = React.useState<IDropdownOption[]>([]);

  // ✅ Fetch employees and managers
  React.useEffect(() => {
    fetch('http://127.0.0.1:8000/employees')
      .then(res => res.json())
      .then(data => setEmployees(data.map((e: any) => ({ key: e.id.toString(), text: e.name }))));

    fetch('http://127.0.0.1:8000/managers')
      .then(res => res.json())
      .then(data => setManagers(data.map((m: any) => ({ key: m.id.toString(), text: m.name }))));
  }, []);

  // ✅ Fetch dashboard data
  React.useEffect(() => {
    let summaryUrl = `http://127.0.0.1:8000/dashboard-summary?filter_type=${filterType}`;
    let trendUrl = `http://127.0.0.1:8000/monthly-expense-trend?filter_type=${filterType}`;
    if (filterType !== 'all' && selectedId) {
      summaryUrl += `&id=${selectedId}`;
      trendUrl += `&id=${selectedId}`;
    }

    fetch(summaryUrl)
      .then(res => res.json())
      .then(data => setSummary(data));

    fetch(trendUrl)
      .then(res => res.json())
      .then(data => setTrend(Array.isArray(data) ? data : [])); // ✅ Safe array check
  }, [filterType, selectedId]);

  if (!summary) return <Text>Loading dashboard...</Text>;

  // ✅ Safe handling for empty trend
  const trendData = {
    labels: (trend || []).map(t => t.month),
    datasets: [
      {
        label: 'Monthly Trend',
        data: (trend || []).map(t => t.total),
        borderColor: '#0078D4',
        backgroundColor: '#0078D4',
        fill: false,
        tension: 0.3
      }
    ]
  };

  const categoryData = {
    labels: (summary.categories || []).map((c: any) => c.category),
    datasets: [
      {
        data: (summary.categories || []).map((c: any) => c.total),
        backgroundColor: ['#0078D4', '#00B294', '#FFB900', '#D83B01']
      }
    ]
  };

  const cardStyle: React.CSSProperties = {
    padding: '16px',
    borderRadius: '8px',
    background: '#f3f2f1',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    minWidth: '220px'
  };

  const stackTokens: IStackTokens = { childrenGap: 20 };
  const stackStyles: IStackStyles = { root: { padding: 20 } };

  return (
    <Stack tokens={stackTokens} styles={stackStyles}>
      <Text variant="xxLarge">Approved Expenses Dashboard</Text>

      {/* ✅ Summary Row with Filter Dropdown to the RIGHT */}
      <Stack horizontal tokens={{ childrenGap: 20 }} styles={{ root: { marginBottom: 20, flexWrap: 'wrap' } }}>
        {/* Total Approved Expenses */}
        <Stack style={cardStyle}>
          <Text variant="large">Total Approved Expenses</Text>
          <Text variant="xLarge">₹{summary.total_expenses.toFixed(2)}</Text>
        </Stack>

        {/* Pending Approvals (Optional) */}
        <Stack style={cardStyle}>
          <Text variant="large">Pending Approvals</Text>
          <Text variant="xLarge">{summary.pending_count}</Text>
        </Stack>

        {/* Filter Options */}
        <Stack style={cardStyle}>
          <Text variant="large">Filter Options</Text>
          <Dropdown
            label="Filter By"
            options={[
              { key: 'all', text: 'All' },
              { key: 'manager', text: 'Manager-wise' },
              { key: 'employee', text: 'Employee-wise' }
            ]}
            selectedKey={filterType}
            onChange={(_, option) => {
              setFilterType(option?.key as string);
              setSelectedId('');
            }}
            styles={{
              dropdown: { width: '100%' },
              dropdownItemsWrapper: { maxHeight: '200px', overflowY: 'auto' }
            }}
          />

          {filterType === 'manager' && (
            <Dropdown
              label="Select Manager"
              options={managers}
              selectedKey={selectedId}
              onChange={(_, option) => setSelectedId(option?.key as string)}
              styles={{
                dropdown: { width: '100%' },
                dropdownItemsWrapper: { maxHeight: '200px', overflowY: 'auto' }
              }}
            />
          )}

          {filterType === 'employee' && (
            <Dropdown
              label="Select Employee"
              options={employees}
              selectedKey={selectedId}
              onChange={(_, option) => setSelectedId(option?.key as string)}
              styles={{
                dropdown: { width: '100%' },
                dropdownItemsWrapper: { maxHeight: '200px', overflowY: 'auto' }
              }}
            />
          )}
        </Stack>
      </Stack>

      {/* ✅ Charts */}
      <Stack horizontal tokens={{ childrenGap: 40 }} styles={{ root: { justifyContent: 'center', flexWrap: 'wrap' } }}>
        <Stack styles={{ root: { width: '45%', textAlign: 'center', minWidth: '300px' } }}>
          <Text variant="large">Monthly Approved Expense Trend</Text>
          <div style={{ width: '100%', height: '300px' }}>
            <Line data={trendData} options={{ maintainAspectRatio: false }} />
          </div>
        </Stack>
        <Stack styles={{ root: { width: '45%', textAlign: 'center', minWidth: '300px' } }}>
          <Text variant="large">Approved Category Breakdown</Text>
          <div style={{ width: '100%', height: '300px', display: 'flex', justifyContent: 'center' }}>
            <Pie data={categoryData} options={{ maintainAspectRatio: false }} />
          </div>
        </Stack>
      </Stack>
    </Stack>
  );
};

export default Dashboard;