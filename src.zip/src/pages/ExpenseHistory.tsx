import * as React from 'react';
import {
  Stack,
  Text,
  Dropdown,
  IDropdownOption,
  DetailsList,
  IColumn
} from '@fluentui/react';

interface Expense {
  date: string;
  category: string;
  amount: number;
  status: string;
  description: string;
}

const ExpenseHistory: React.FC = () => {
  const [employees, setEmployees] = React.useState<IDropdownOption[]>([]);
  const [selectedEmployee, setSelectedEmployee] = React.useState<string>('');
  const [history, setHistory] = React.useState<Expense[]>([]);
  const [loading, setLoading] = React.useState(false);

  // ✅ Fetch employees for dropdown
  React.useEffect(() => {
    fetch('http://127.0.0.1:8000/employees')
      .then(res => res.json())
      .then(data => {
        const options = data.map((emp: any) => ({
          key: emp.id.toString(),
          text: emp.name
        }));
        setEmployees(options);
      })
      .catch(() => console.error('Error loading employees'));
  }, []);

  // ✅ Fetch expense history when employee changes
  React.useEffect(() => {
    if (!selectedEmployee) return;
    setLoading(true);
    fetch(`http://127.0.0.1:8000/expense-history/${selectedEmployee}`)
      .then(res => res.json())
      .then(data => {
        setHistory(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [selectedEmployee]);

  const columns: IColumn[] = [
    { key: 'date', name: 'Date', fieldName: 'date', minWidth: 100 },
    { key: 'category', name: 'Category', fieldName: 'category', minWidth: 100 },
    { key: 'amount', name: 'Amount', fieldName: 'amount', minWidth: 80 },
    { key: 'status', name: 'Status', fieldName: 'status', minWidth: 100 },
    { key: 'description', name: 'Description', fieldName: 'description', minWidth: 200 }
  ];

  return (
    <Stack tokens={{ childrenGap: 16 }} styles={{ root: { padding: 20 } }}>
      <Text variant="xLarge">Expense History</Text>

      {/* Employee Dropdown */}
      <Dropdown
        label="Select Employee"
        options={employees}
        selectedKey={selectedEmployee}
        onChange={(_, option) => setSelectedEmployee(option?.key as string)}
        placeholder="Choose an employee"
      />

      {loading ? (
        <Text>Loading expense history...</Text>
      ) : (
        <DetailsList items={history} columns={columns} />
      )}
    </Stack>
  );
};

export default ExpenseHistory;