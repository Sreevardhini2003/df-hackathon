import * as React from 'react';
import {
  DetailsList,
  IColumn,
  PrimaryButton,
  DefaultButton,
  Stack,
  Text,
  Dropdown,
  IDropdownOption
} from '@fluentui/react';

interface Approval {
  id: number;
  date: string;
  employeeName: string;
  category: string;
  amount: number;
  status: string;
}

const ManagerApprovals: React.FC = () => {
  const [approvals, setApprovals] = React.useState<Approval[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [managers, setManagers] = React.useState<IDropdownOption[]>([]);
  const [selectedManager, setSelectedManager] = React.useState<string>('');

  // ✅ Fetch managers dynamically
  React.useEffect(() => {
    fetch('http://127.0.0.1:8000/managers') // New endpoint for managers
      .then(res => res.json())
      .then(data => {
        const options = data.map((mgr: any) => ({
          key: mgr.id,
          text: mgr.name
        }));
        setManagers(options);
      })
      .catch(() => console.error('Error loading managers'));
  }, []);

  // ✅ Fetch approvals when manager changes
  React.useEffect(() => {
    if (!selectedManager) return;
    setLoading(true);
    fetch(`http://127.0.0.1:8000/pending-approvals/${selectedManager}`)
      .then(res => res.json())
      .then(data => {
        setApprovals(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [selectedManager]);

  const handleAction = (id: number, action: 'approve' | 'reject') => {
    fetch(`http://127.0.0.1:8000/${action}/${id}`, { method: 'PUT' })
      .then(() => {
        setApprovals(prev =>
          prev.map(a =>
            a.id === id ? { ...a, status: action === 'approve' ? 'Approved' : 'Rejected' } : a
          )
        );
      });
  };

  const columns: IColumn[] = [
    { key: 'date', name: 'Date', fieldName: 'date', minWidth: 100 },
    { key: 'employeeName', name: 'Employee', fieldName: 'employeeName', minWidth: 150 },
    { key: 'category', name: 'Category', fieldName: 'category', minWidth: 100 },
    { key: 'amount', name: 'Amount', fieldName: 'amount', minWidth: 80 },
    { key: 'status', name: 'Status', fieldName: 'status', minWidth: 100 },
    {
      key: 'actions',
      name: 'Actions',
      minWidth: 200,
      onRender: (item: Approval) => (
        <Stack horizontal tokens={{ childrenGap: 8 }}>
          <PrimaryButton
            text="Approve"
            disabled={item.status !== 'Pending'}
            onClick={() => handleAction(item.id, 'approve')}
          />
          <DefaultButton
            text="Reject"
            disabled={item.status !== 'Pending'}
            onClick={() => handleAction(item.id, 'reject')}
          />
        </Stack>
      )
    }
  ];

  return (
    <Stack tokens={{ childrenGap: 16 }} styles={{ root: { padding: 20 } }}>
      <Text variant="xLarge">Manager Approvals</Text>

      {/* ✅ Manager Dropdown */}
      <Dropdown
        label="Select Manager"
        options={managers}
        selectedKey={selectedManager}
        onChange={(_, option) => setSelectedManager(option?.key as string)}
        placeholder="Choose a manager"
      />

      {loading ? (
        <Text>Loading approvals...</Text>
      ) : (
        <DetailsList items={approvals} columns={columns} />
      )}
    </Stack>
  );
};

export default ManagerApprovals;