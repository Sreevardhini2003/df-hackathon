import * as React from 'react';
import {
  Stack,
  Text,
  Dropdown,
  IDropdownOption,
  PrimaryButton,
  DatePicker
} from '@fluentui/react';

const reportOptions: IDropdownOption[] = [
  { key: 'employee', text: 'Employee-wise' },
  { key: 'manager', text: 'Manager-wise' },
  { key: 'all', text: 'All Expenses' }
];

const ReportsExport: React.FC = () => {
  const [reportType, setReportType] = React.useState<string>('');
  const [employees, setEmployees] = React.useState<IDropdownOption[]>([]);
  const [managers, setManagers] = React.useState<IDropdownOption[]>([]);
  const [selectedId, setSelectedId] = React.useState<string>('');
  const [startDate, setStartDate] = React.useState<Date | null>(null);
  const [endDate, setEndDate] = React.useState<Date | null>(null);

  React.useEffect(() => {
    fetch('http://127.0.0.1:8000/employees')
      .then(res => res.json())
      .then(data => {
        const empOptions = data.map((emp: any) => ({ key: emp.id.toString(), text: emp.name }));
        setEmployees(empOptions);
      });

    fetch('http://127.0.0.1:8000/managers')
      .then(res => res.json())
      .then(data => {
        const mgrOptions = data.map((mgr: any) => ({ key: mgr.id, text: mgr.name }));
        setManagers(mgrOptions);
      });
  }, []);

  const handleDownload = () => {
    if (!startDate || !endDate) return alert('Please select start and end dates');
    let url = `http://127.0.0.1:8000/export-report?report_type=${reportType}&start_date=${startDate.toISOString().split('T')[0]}&end_date=${endDate.toISOString().split('T')[0]}`;
    if (reportType !== 'all') {
      url += `&id=${selectedId}`;
    }
    window.open(url, '_blank');
  };

  return (
    <Stack tokens={{ childrenGap: 16 }} styles={{ root: { padding: 20, maxWidth: 500 } }}>
      <Text variant="xLarge">Export Reports</Text>

      <Dropdown
        label="Select Report Type"
        options={reportOptions}
        selectedKey={reportType}
        onChange={(_, option) => {
          setReportType(option?.key as string);
          setSelectedId('');
        }}
      />

      {reportType === 'employee' && (
        <Dropdown
          label="Select Employee"
          options={employees}
          selectedKey={selectedId}
          onChange={(_, option) => setSelectedId(option?.key as string)}
        />
      )}

      {reportType === 'manager' && (
        <Dropdown
          label="Select Manager"
          options={managers}
          selectedKey={selectedId}
          onChange={(_, option) => setSelectedId(option?.key as string)}
        />
      )}

      <DatePicker
        label="Start Date"
        value={startDate || undefined}
        onSelectDate={(date) => setStartDate(date || null)}
      />

      <DatePicker
        label="End Date"
        value={endDate || undefined}
        onSelectDate={(date) => setEndDate(date || null)}
      />

      <PrimaryButton
        text="Download Report"
        onClick={handleDownload}
        disabled={!reportType || !startDate || !endDate || (reportType !== 'all' && !selectedId)}
      />
    </Stack>
  );
};

export default ReportsExport;