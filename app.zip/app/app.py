from fastapi import FastAPI, Form, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import sqlite3
import shutil
import os
import time
from datetime import datetime

app = FastAPI()
from fastapi.staticfiles import StaticFiles

# Serve frontend from dist folder
app.mount("/", StaticFiles(directory="dist", html=True), name="frontend")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# SQLite Database Configuration
# -----------------------------
DB_PATH = "expense.db"

# ensure db file exists
def get_conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)

# -----------------------------
# Database Initialization
# -----------------------------
def init_db():
    conn = get_conn()
    cursor = conn.cursor()

    # Employees Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Employees (
        EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT,
        Name TEXT,
        Email TEXT,
        Department TEXT,
        ManagerID TEXT
    )
    """)

    # Expenses Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Expenses (
        ExpenseID INTEGER PRIMARY KEY AUTOINCREMENT,
        EmployeeID INTEGER,
        Amount REAL,
        Category TEXT,
        ExpenseDate TEXT,
        Description TEXT,
        ReceiptPath TEXT,
        Status TEXT DEFAULT 'Pending',
        SubmittedOn TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
    )
    """)

    conn.commit()
    conn.close()

init_db()


# -----------------------------
# Insert Initial Employees (Seed Data)
# -----------------------------
def reset_and_seed_employees():
    conn = get_conn()
    cursor = conn.cursor()

    # 2️⃣ Insert only the employees with 3 managers: M001, M002, M003
    employees = [
        ("John Doe", "john.doe@example.com", "Finance", "M001"),
        ("Alice Smith", "alice.smith@example.com", "IT", "M002"),
        ("Michael Brown", "michael.brown@example.com", "Finance", "M001"),
        ("Emma Wilson", "emma.wilson@example.com", "HR", "M003"),
        ("William Clark", "william.clark@example.com", "IT", "M002"),
        ("Olivia Walker", "olivia.walker@example.com", "Finance", "M001"),
        ("James Hall", "james.hall@example.com", "Operations", "M003"),
        ("Benjamin Young", "benjamin.young@example.com", "HR", "M003"),
        ("Charlotte King", "charlotte.king@example.com", "Finance", "M001"),
        ("Henry Wright", "henry.wright@example.com", "IT", "M002"),
        ("Amelia Scott", "amelia.scott@example.com", "Operations", "M003"),
        ("Daniel Green", "daniel.green@example.com", "Finance", "M001"),
        ("Grace Adams", "grace.adams@example.com", "HR", "M003"),
        ("Mia Campbell", "mia.campbell@example.com", "IT", "M002"),
        ("Ethan Mitchell", "ethan.mitchell@example.com", "Operations", "M003"),
        ("Harper Carter", "harper.carter@example.com", "Finance", "M001")
    ]

    cursor.executemany("""
        INSERT INTO Employees (Name, Email, Department, ManagerID)
        VALUES (?, ?, ?, ?)
    """, employees)

    conn.commit()
    conn.close()



# Seed only once at startup
reset_and_seed_employees()

# -----------------------------
# Upload directory
# -----------------------------
upload_dir = "./uploads"
os.makedirs(upload_dir, exist_ok=True)


# -----------------------------
# Submit Expense
# -----------------------------
@app.post("/submit-expense")
async def submit_expense(
    employee_id: int = Form(...),
    amount: float = Form(...),
    category: str = Form(...),
    expense_date: str = Form(...),
    description: str = Form(...),
    receipt: UploadFile = None
):
    file_path = None
    if receipt:
        file_path = os.path.join(upload_dir, receipt.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(receipt.file, buffer)

    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Expenses (EmployeeID, Amount, Category, ExpenseDate, Description, ReceiptPath)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (employee_id, amount, category, expense_date, description, file_path))
    conn.commit()
    conn.close()

    return {"message": "Expense submitted successfully!"}

# -----------------------------
# Employees list
# -----------------------------
@app.get("/employees")
async def get_employees():
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT EmployeeID, Name FROM Employees")
    rows = cursor.fetchall()
    conn.close()

    return [{"id": r[0], "name": r[1]} for r in rows]

# -----------------------------
# Managers list
# -----------------------------
@app.get("/managers")
async def get_managers():
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT ManagerID FROM Employees WHERE ManagerID IS NOT NULL")
    rows = cursor.fetchall()
    conn.close()

    return [{"id": r[0], "name": r[0]} for r in rows]

# -----------------------------
# Pending Approvals
# -----------------------------
@app.get("/pending-approvals/{manager_id}")
async def pending_approvals(manager_id: str):
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT e.ExpenseID, e.ExpenseDate, e.Amount, e.Category, e.Status, emp.Name
        FROM Expenses e
        JOIN Employees emp ON e.EmployeeID = emp.EmployeeID
        WHERE e.Status='Pending' AND emp.ManagerID=?
    """, (manager_id,))
    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "id": r[0],
            "date": r[1],
            "amount": r[2],
            "category": r[3],
            "status": r[4],
            "employeeName": r[5]
        }
        for r in rows
    ]

# -----------------------------
# Approve / Reject
# -----------------------------
@app.put("/approve/{expense_id}")
async def approve_expense(expense_id: int):
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("UPDATE Expenses SET Status='Approved' WHERE ExpenseID=?", (expense_id,))
    conn.commit()
    conn.close()
    return {"message": "Expense approved"}

@app.put("/reject/{expense_id}")
async def reject_expense(expense_id: int):
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("UPDATE Expenses SET Status='Rejected' WHERE ExpenseID=?", (expense_id,))
    conn.commit()
    conn.close()
    return {"message": "Expense rejected"}

# -----------------------------
# Expense History
# -----------------------------
@app.get("/expense-history/{employee_id}")
async def expense_history(employee_id: int):
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ExpenseDate, Category, Amount, Status, Description
        FROM Expenses
        WHERE EmployeeID=?
        ORDER BY ExpenseDate DESC
    """, (employee_id,))
    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "date": r[0],
            "category": r[1],
            "amount": r[2],
            "status": r[3],
            "description": r[4]
        }
        for r in rows
    ]

# -----------------------------
# Dashboard Summary
# -----------------------------
@app.get("/dashboard-summary")
async def dashboard_summary(filter_type: str = None, id: str = None):
    conn = get_conn()
    cursor = conn.cursor()

    # Total approved expenses
    if filter_type == "manager":
        cursor.execute("""
            SELECT IFNULL(SUM(e.Amount), 0)
            FROM Expenses e
            JOIN Employees emp ON e.EmployeeID = emp.EmployeeID
            WHERE emp.ManagerID=? AND e.Status='Approved'
        """, (id,))
    elif filter_type == "employee":
        cursor.execute("""
            SELECT IFNULL(SUM(Amount), 0)
            FROM Expenses
            WHERE EmployeeID=? AND Status='Approved'
        """, (id,))
    else:
        cursor.execute("SELECT IFNULL(SUM(Amount), 0) FROM Expenses WHERE Status='Approved'")
    total = cursor.fetchone()[0]

    # Pending count
    cursor.execute("SELECT COUNT(*) FROM Expenses WHERE Status='Pending'")
    pending = cursor.fetchone()[0]

    # Category breakdown
    if filter_type == "manager":
        cursor.execute("""
            SELECT Category, SUM(e.Amount)
            FROM Expenses e
            JOIN Employees emp ON e.EmployeeID = emp.EmployeeID
            WHERE emp.ManagerID=? AND e.Status='Approved'
            GROUP BY Category
        """, (id,))
    elif filter_type == "employee":
        cursor.execute("""
            SELECT Category, SUM(Amount)
            FROM Expenses
            WHERE EmployeeID=? AND Status='Approved'
            GROUP BY Category
        """, (id,))
    else:
        cursor.execute("""
            SELECT Category, SUM(Amount)
            FROM Expenses
            WHERE Status='Approved'
            GROUP BY Category
        """)
    categories = [{"category": r[0], "total": r[1]} for r in cursor.fetchall()]

    conn.close()
    return {
        "total_expenses": total,
        "pending_count": pending,
        "categories": categories
    }

# -----------------------------
# Monthly Expense Trend
# -----------------------------
@app.get("/monthly-expense-trend")
async def monthly_expense_trend(filter_type: str = None, id: str = None):
    conn = get_conn()
    cursor = conn.cursor()

    query = """
        SELECT substr(ExpenseDate, 1, 7) AS Month, SUM(Amount)
        FROM Expenses
        WHERE Status='Approved'
    """

    params = []

    if filter_type == "manager":
        query += """
            AND EmployeeID IN (SELECT EmployeeID FROM Employees WHERE ManagerID=?)
        """
        params.append(id)

    if filter_type == "employee":
        query += " AND EmployeeID=?"
        params.append(id)

    query += " GROUP BY substr(ExpenseDate,1,7) ORDER BY substr(ExpenseDate,1,7)"

    cursor.execute(query, tuple(params))
    rows = cursor.fetchall()
    conn.close()

    return [{"month": r[0], "total": r[1]} for r in rows]
